/*
 * Nuvio BR — modelo inicial
 *
 * Este arquivo NÃO encontra nem hospeda vídeos ainda.
 * Ele existe para documentar a estrutura esperada de um provider.
 * Não habilite esperando obter filmes: getStreams retorna uma lista vazia
 * até que uma fonte legítima e compatível seja implementada e testada.
 */

function getStreams(tmdbId, mediaType, season, episode) {
  console.log("[Nuvio BR] Nenhuma fonte de reprodução foi configurada.");
  return Promise.resolve([]);
}

module.exports = { getStreams };
