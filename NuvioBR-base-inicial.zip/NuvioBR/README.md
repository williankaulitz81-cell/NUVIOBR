# Nuvio BR — base inicial

**Status: protótipo; não é um repositório de fontes pronto para instalar.**

Este projeto documenta uma base para um repositório de plugins do Nuvio com metadados de idioma `pt-BR`/`pt`. Ele **não inclui fontes funcionais de filmes ou séries**. O provider de exemplo retorna uma lista vazia de propósito, para não fingir que existe uma busca funcional.

## O que este projeto pode e não pode fazer

- O campo `contentLanguage` descreve o idioma associado ao provider; ele não força o vídeo a ter dublagem brasileira.
- O plugin precisa de código compatível que consulte fontes de reprodução legítimas e devolva URLs de streams.
- A disponibilidade de áudio dublado depende do vídeo encontrado. Legendas em português não transformam áudio original em dublagem.
- A preferência de áudio e legenda deve ser configurada separadamente no player do Nuvio, quando essas opções estiverem disponíveis.

## Estrutura

- `manifest.json`: registro do provider de exemplo.
- `providers/nuvio-br-template.js`: esqueleto de provider.
- `README.md`: documentação e limitações.

## Antes de publicar

1. Escolha e verifique uma fonte legítima que permita acesso aos streams.
2. Implemente a extração de fontes de acordo com a versão atual do Nuvio.
3. Teste títulos, filmes e episódios, falhas de rede e metadados de idioma.
4. Só então habilite o provider e publique o manifesto num repositório GitHub.

**Não cole o manifesto deste protótipo no Nuvio esperando que ele encontre filmes.** Ele é apenas a base do projeto, ainda sem fornecedores de reprodução funcionais.
